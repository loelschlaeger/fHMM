library(testthat)
library(fHMM)

test_check("fHMM")
